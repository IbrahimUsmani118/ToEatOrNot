//
//  AppDelegate.swift
//  Main storyboard
//
//  Created by Abhay Patel on 5/3/21
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
}

